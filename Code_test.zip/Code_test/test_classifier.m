close all
clear all
clc
load('ANN_data.mat')
ANN_out =[];
Y_out=[];
[a_m a_n]=size(X_test);
error =0;
for i=1:a_n
    [Y,Xf,Af] = myNeuralNetworkFunction(X_test(:,i));
    Y_out = [Y_out Y];
    if(Y(1,1)>Y(2,1))
        ANN_out=[ANN_out [1 0]'];
        if(y_test(:,i)~= [1;0])
            error=error+1;
        else
            error = error+0;
        end
    else
        ANN_out=[ANN_out [0 1]'];
        if(y_test(:,i)~= [0;1])
            error=error+1;
        else
            error = error+0;
        end
    end
end
