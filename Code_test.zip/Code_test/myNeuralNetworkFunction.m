function [Y,Xf,Af] = myNeuralNetworkFunction(X,~,~)
%MYNEURALNETWORKFUNCTION neural network simulation function.
%
% [Y] = myNeuralNetworkFunction(X,~,~) takes these arguments:
%
%   X = 1xTS cell, 1 inputs over TS timesteps
%   Each X{1,ts} = 4xQ matrix, input #1 at timestep ts.
%
% and returns:
%   Y = 1xTS cell of 1 outputs over TS timesteps.
%   Each Y{1,ts} = 2xQ matrix, output #1 at timestep ts.
%
% where Q is number of samples (or series) and TS is the number of timesteps.

%#ok<*RPMT0>

% ===== NEURAL NETWORK CONSTANTS =====

% Input 1
x1_step1.xoffset = [52.002997126064;13.9511833016275;0.0831582409045635;15.4097782160154];
x1_step1.gain = [0.0270162192586387;0.0303204449866555;0.671756201340412;0.0234217566988106];
x1_step1.ymin = -1;

% Layer 1
b1 = [-2.3804412788636546;-0.66854117816164327;1.689792112653949;2.1602962581747667;0.72748697050039646;0.52937965165190004;1.7307396126037671;1.3385489368707393;-2.1007334723389324;2.5000076659459509];
IW1_1 = [1.5733252683027041 0.93287355808720729 -0.016251195639728957 1.8357260902386059;1.8511076361550698 -1.9658233766981839 1.6894875666246745 0.070684827596455294;-0.22614174127652306 -1.0935777142857432 1.5164347179482152 1.7501402319118051;1.0903229746355279 0.27315701291663474 3.4279662223322105 -0.32411439859410546;-2.637547258734005 1.8313954379979893 -0.32038649932975827 -1.2174210804831418;0.28137784372526897 -0.5752147171712626 -2.0378169597382887 -0.9843682539413473;1.3879849514892384 0.27058066431999378 -1.5110928128441159 0.72454203151298846;1.267473923598206 -1.7838138705697621 -0.97893093753558857 -0.21274532953516934;-1.1087410289887125 1.299360083357443 1.489599194027871 -0.82613612079887666;0.83761198676278426 -1.1756431329749226 -1.2603299008037658 1.583928698305592];

% Layer 2
b2 = [-0.20902989123319188;-0.11147375366477294];
LW2_1 = [0.58720885118118837 1.403346880546595 1.177271239142595 2.24042086669089 -2.1892334300116008 0.42149987958947377 0.49630351818808488 0.27045354574169728 -1.0457955728118269 -0.50467466890483104;-0.317233452293461 -0.99728151524622732 -0.15541259236416183 -2.3438858912897342 0.44884224647094167 0.19842968663249425 -0.36846973278225842 -0.19402494188089997 -0.25615499938792735 0.4176083666591307];

% ===== SIMULATION ========

% Format Input Arguments
isCellX = iscell(X);
if ~isCellX
    X = {X};
end

% Dimensions
TS = size(X,2); % timesteps
if ~isempty(X)
    Q = size(X{1},2); % samples/series
else
    Q = 0;
end

% Allocate Outputs
Y = cell(1,TS);

% Time loop
for ts=1:TS
    
    % Input 1
    Xp1 = mapminmax_apply(X{1,ts},x1_step1);
    
    % Layer 1
    a1 = tansig_apply(repmat(b1,1,Q) + IW1_1*Xp1);
    
    % Layer 2
    a2 = softmax_apply(repmat(b2,1,Q) + LW2_1*a1);
    
    % Output 1
    Y{1,ts} = a2;
end

% Final Delay States
Xf = cell(1,0);
Af = cell(2,0);

% Format Output Arguments
if ~isCellX
    Y = cell2mat(Y);
end
end

% ===== MODULE FUNCTIONS ========

% Map Minimum and Maximum Input Processing Function
function y = mapminmax_apply(x,settings)
y = bsxfun(@minus,x,settings.xoffset);
y = bsxfun(@times,y,settings.gain);
y = bsxfun(@plus,y,settings.ymin);
end

% Competitive Soft Transfer Function
function a = softmax_apply(n,~)
if isa(n,'gpuArray')
    a = iSoftmaxApplyGPU(n);
else
    a = iSoftmaxApplyCPU(n);
end
end
function a = iSoftmaxApplyCPU(n)
nmax = max(n,[],1);
n = bsxfun(@minus,n,nmax);
numerator = exp(n);
denominator = sum(numerator,1);
denominator(denominator == 0) = 1;
a = bsxfun(@rdivide,numerator,denominator);
end
function a = iSoftmaxApplyGPU(n)
nmax = max(n,[],1);
numerator = arrayfun(@iSoftmaxApplyGPUHelper1,n,nmax);
denominator = sum(numerator,1);
a = arrayfun(@iSoftmaxApplyGPUHelper2,numerator,denominator);
end
function numerator = iSoftmaxApplyGPUHelper1(n,nmax)
numerator = exp(n - nmax);
end
function a = iSoftmaxApplyGPUHelper2(numerator,denominator)
if (denominator == 0)
    a = numerator;
else
    a = numerator ./ denominator;
end
end

% Sigmoid Symmetric Transfer Function
function a = tansig_apply(n,~)
a = 2 ./ (1 + exp(-2*n)) - 1;
end
