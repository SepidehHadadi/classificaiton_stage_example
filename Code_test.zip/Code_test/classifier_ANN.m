clear all
close all
clc
%% read data and set value for class
% sheet = 1;
% xlRange = 'A:E';
% [~,~,data]= xlsread('data.xlsx', sheet, xlRange,'basic');
load('original_data.mat')
[m n]=size(data);
all_data=zeros(m-1,5);
target =zeros(m-1,2);
all_data(:,1:4)=cell2mat(data(2:m,1:4));
for i=2:m
    if(strcmp(data(i,5), data(4,5)))
        all_data(i-1,5)= 2;%rest
        target(i-1,:)= [0 1];
    else
        all_data(i-1,5)= 1;%stress
        target(i-1,:)= [1 0];
    end
end
%% ANN classifier and training
%training dataset
X=all_data(1:1000,1:4)';
Y=target(1:1000,:)';
X_test=all_data(1000:m-1,1:4)';
y_test=target(1000:m-1,:)';
